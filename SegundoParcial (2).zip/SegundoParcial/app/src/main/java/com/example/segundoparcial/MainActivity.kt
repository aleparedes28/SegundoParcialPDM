package com.example.segundoparcial

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import com.airbnb.lottie.LottieAnimationView

class MainActivity : AppCompatActivity() {

    private lateinit var Login: LottieAnimationView
    private lateinit var editUsername: EditText
    private lateinit var editPassword: EditText
    private lateinit var btnIniciar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editPassword = findViewById(R.id.editPassword)
        editUsername = findViewById(R.id.editUsername)
        btnIniciar = findViewById(R.id.btnIniciar)
        Login = findViewById(R.id.LoginAnim)

        Login.visibility = View.INVISIBLE


        btnIniciar.setOnClickListener {
            var passwordInput = editPassword.text.toString()
            var usernameInput = editUsername.text.toString()

            if (usernameInput == "SegundoParcial" && passwordInput == "ULSA2021"){
                val intent = Intent(this, WelcomeActivity::class.java)
                intent.putExtra("username", usernameInput)
                startActivity(intent)
            }
            else{
                Login.visibility = View.VISIBLE
            }


        }
    }
}