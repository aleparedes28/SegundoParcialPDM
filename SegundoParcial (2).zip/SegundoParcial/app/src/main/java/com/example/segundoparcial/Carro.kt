package com.example.segundoparcial

data class Carro (val Marca:String, val Modelo:String, val Year:String, val urlImage:String, val latitude:Double, val longitude:Double)

