package com.example.segundoparcial

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    var longitude = 0.0
    var latitude = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        longitude = intent.getDoubleExtra("longitude",0.0)
        latitude = intent.getDoubleExtra("latitude", 0.0)

    }
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        val direction = LatLng(latitude, longitude)
        val zoomLevel = 18.0f
        mMap.addMarker(
            MarkerOptions()
                .position(direction)
                .title("Direccion"))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(direction, zoomLevel))
    }
}