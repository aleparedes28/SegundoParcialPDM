package com.example.segundoparcial

import android.content.Intent
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso

class WelcomeActivity : AppCompatActivity() {

    private lateinit var btnSiguiente: Button
    private lateinit var btnVer: Button
    private lateinit var btnCerrar: Button
    private lateinit var btnAgregar: Button
    private lateinit var txtBienvenido: TextView
    private lateinit var txtMarca: TextView
    private lateinit var txtModelo: TextView
    private lateinit var txtYear: TextView
    private lateinit var imageView: ImageView
    private var currentIndex = 0

    private var CarroBank = mutableListOf<Carro>(
        Carro(
            "RAM",
            "1500TRX",
            "2021",
            "https://i.blogs.es/b091db/ram-1500-trx-launch-edition-2021_6/1366_2000.jpg",
            32.8370727,
            -97.0819541
        ),
        Carro(
            "Mercedes",
            "E 320",
            "2006",
            "https://www.km77.com/media/fotos/mercedes_clase_e_2002_berlina_1026_1.jpg",
            32.4250426,
            -97.1326090
        ),
        Carro(
            "Nissan",
            "Versa",
            "2020",
            "https://www.nissan.com.mx/content/dam/Nissan/mexico/ServicioNissan/AsistenciaVial/AsistenciaVial-Sentra_Camino.jpg.ximg.l_6_m.smart.jpg",
            34.6194746,
            -100.4450221
        ),
        Carro(
            "Nissan",
            "Kiks",
            "2020",
            "https://www.elcarrocolombiano.com/wp-content/uploads/2021/03/20210317-NISSAN-KICKS-2021-RESENA-VIDEO-CAMBIOS-COLOMBIA-PRECIO-CARACTERISTICAS-01.jpg",
            61.8177664,
            -111.9872506
        ),
        Carro(
            "BMW",
            "m3",
            "2021",
            "https://www.autonocion.com/wp-content/uploads/2020/12/Contacto-BMW-M3-y-BMW-M4-Coup%C3%A9-Competition-2021-25-930x620.jpg",
            50.8589713,
            39.8644374
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        imageView = findViewById(R.id.imageView)
        Picasso.get().setLoggingEnabled(true)
        Picasso.get().load(CarroBank[currentIndex].urlImage).centerCrop().resize(300, 150).into(imageView)

        btnSiguiente = findViewById(R.id.btnSiguiente)
        btnVer = findViewById(R.id.btnVer)
        btnCerrar = findViewById(R.id.btnCerrar)
        btnAgregar = findViewById(R.id.btnAgregar)
        txtBienvenido = findViewById(R.id.txtBienvenido)
        txtMarca = findViewById(R.id.txtMarca)
        txtYear = findViewById(R.id.txtYear)
        txtModelo = findViewById(R.id.txtModelo)
        val usernameInput = intent.getStringExtra("username")
        val nuevoTexto = "Bienvenido: ${usernameInput.toString()}"
        txtBienvenido.setText(nuevoTexto)

        val Marca = intent.getStringExtra("Marca")
        val Modelo = intent.getStringExtra("Modelo")
        val urlImage = intent.getStringExtra("urlImage")
        val latitude = intent.getStringExtra("latitude")
        val longitude = intent.getStringExtra("longitude")
        val Year = intent.getStringExtra("Year")

        if (Marca != null){
            CarroBank.add(Carro(Marca.toString(), Modelo.toString(), Year.toString(), urlImage.toString(), latitude.toString().toDouble(), longitude.toString().toDouble()))
        }


        btnVer.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            intent.putExtra("latitude", CarroBank[currentIndex].latitude)
            intent.putExtra("longitude", CarroBank[currentIndex].longitude)
            startActivity(intent)
        }

        btnAgregar.setOnClickListener {
            val intent = Intent(this, QrActivity::class.java).apply {
            }
            startActivity(intent)
        }
        btnCerrar.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java).apply {
            }
            startActivity(intent)
        }


        btnSiguiente.setOnClickListener {
            currentIndex = (currentIndex + 1) % CarroBank.size
            siguienteCarro()

        }

    }

    private fun siguienteCarro() {
        var imagen = CarroBank[currentIndex].urlImage
        Picasso.get().load(imagen).centerCrop().resize(300, 150).into(imageView)

        var Marca = CarroBank[currentIndex].Marca
        txtMarca.setText(Marca)

        var Modelo = CarroBank[currentIndex].Modelo
        txtModelo.setText(Modelo)

        var Year = CarroBank[currentIndex].Year
        txtYear.setText(Year)
    }

}